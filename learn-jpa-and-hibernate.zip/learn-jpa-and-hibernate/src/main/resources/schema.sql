create table course(
  id bigint not null,
  name varchar(20) not null,
  author varchar(20) not null,
  primary key(id)
);