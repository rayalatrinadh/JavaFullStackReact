package com.trinadh.learnspringframework.examples.d1;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

import com.trinadh.learnspringframework.business.BusinessCalculationService;


@Controller
@ComponentScan("com.trinadh.learnspringframework.data")
@ComponentScan("com.trinadh.learnspringframework.business")
public class RealTimeSpringApplication {
	
public static void main(String args[]) {
		
		try(var context = new AnnotationConfigApplicationContext(RealTimeSpringApplication.class)){
			
			System.out.println("getBeanDefinitionNames \n ");
			Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out :: println);
			
			System.out.println("output  : ");
			System.out.println(context.getBean(BusinessCalculationService.class).findMax());
			
				
			
		}
	}

}
