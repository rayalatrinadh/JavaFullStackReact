package com.trinadh.learnspringframework.data;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("MySQLDataServiceQualifier")
public class MySQLDataService implements DataService{
	
	public int[] retrieveData() {
		
		return new int[] {2,3,4,4};
	}

}
