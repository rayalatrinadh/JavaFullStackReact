package com.trinadh.learnspringframework.data;

public interface DataService {
	int[] retrieveData();

}
