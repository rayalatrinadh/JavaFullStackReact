package com.trinadh.learnspringframework.game;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("SuperContraGameQualifier")
public class SuperContraGame implements GamingConsole{
	
	public void up() {
		System.out.println("move forward");
	}
	public void down() {
		System.out.println("sit down");
	}
	public void right() {
		System.out.println("go right");
	}
	public void left() {
		System.out.println("go left");
	}

}
