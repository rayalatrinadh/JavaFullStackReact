package com.trinadh.learnspringframework.game;

import org.springframework.stereotype.Component;

@Component
public class TrinadhGame implements GamingConsole{
	public void up() {
		System.out.println("trinadh jump");
	}
	public void down() {
		System.out.println("triadh please relax");
	}
	public void left() {
		System.out.println("triandh go left");
	}
	public void right() {
		System.out.println("trinadh go right");
	}

}
