package com.trinadh.learnspringframework.examples.g1;





import java.util.Arrays;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;


@Component
class ClassA{
	
}


@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Component
class ClassB{
		
}

@Configuration
@ComponentScan
public class XmlContextLauncherApplication
{

	
   public static void main(String args[]) {
	   
	   //1: Launching a spring context
	try( var context =  new ClassPathXmlApplicationContext("contextConfiguration.xml")){
		
		Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);
		
		System.out.println(context.getBean("name"));
		System.out.println(context.getBean("age"));
		
	}
  }

}
